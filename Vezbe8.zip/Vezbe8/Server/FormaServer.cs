﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ServerConsole
{
    public partial class FormaServer : Form
    {
        Server s;
        public FormaServer()
        {
            InitializeComponent();
        }

        private void FormaServer_Load(object sender, EventArgs e)
        {
            s = new Server();
            if (s.pokreniServer())
            {
                this.Text = "Server pokrenut";
            }
        }
    }
}










































//System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();
//t.Interval = 5000;
//t.Tick += osvezi;
//t.Start();


//KlasaZaServer k = dataGridView1.CurrentRow.DataBoundItem as KlasaZaServer;
//string jmbg = k.Jmbg;
//bool uspesno = Broker.dajSesiju().obrisiPrijavu(jmbg);