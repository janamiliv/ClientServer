﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Data;
using System.Data.SqlClient;

namespace ServerConsole
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        static Broker instanca;

        public static Broker dajSesiju()
        {
            if (instanca == null)
                instanca = new Broker();
            return instanca;
        }
    }
}
































//public List<Objekat> vratiSveObjekte()
//{
//    List<Objekat> lista = new List<Objekat>();
//    try
//    {
//        konekcija.Open();
//        komanda.CommandText = "Select * from Objekat";
//        SqlDataReader citac = komanda.ExecuteReader();
//        while (citac.Read())
//        {
//            Objekat o = new Objekat();
//            o.Id = citac.GetInt32(0);
//            o.Naziv = citac.GetString(1);
//            lista.Add(o);
//        }

//        citac.Close();
//        return lista;
//    }
//    catch (Exception)
//    {

//        throw;
//    }
//    finally
//    {
//        if (konekcija != null) konekcija.Close();

//    }
//}


//public int vratiSifruPara()
//{
//    try
//    {
//        komanda.CommandText = "Select max(ID) from Par";
//        try
//        {
//            int sifra = Convert.ToInt32(komanda.ExecuteScalar());
//            return sifra + 1;
//        }
//        catch (Exception)
//        {

//            return 1;
//        }
//    }
//    catch (Exception)
//    {

//        throw;
//    }


//}

//Sacuvaj parove:

//	public bool sacuvajParove(List<Par> lista)
//{
//    try
//    {
//        konekcija.Open();
//        // kada cuvamo listu koristimo transakcije
//        transakcija = konekcija.BeginTransaction();
//        komanda = new SqlCommand("", konekcija, transakcija);
//        foreach (Par par in lista)
//        {
//            par.Id = vratiSifruPara();
//            komanda.CommandText = "Insert into Par values (" + par.Id + ", " + par.Domacin.Id + ", " + par.Gost.Id + ", '" + par.Datum.ToString("yyyy-MM-dd") + "')";
//            komanda.ExecuteNonQuery();
//        }
//        transakcija.Commit();
//        return true;
//    }
//    catch (Exception)
//    {

//        transakcija.Rollback();
//        return false;
//    }
//    finally
//    {
//        if (konekcija != null) konekcija.Close();
//    }
//}

//Kad ima vise da se cuva, moze ovako:

//	if (komanda.ExecuteNonQuery() == 1)
//{
//    transakcija.Commit();
//    return kompanija.KompanijaId;
//}
//else
//{
//    return 0;
//}


//public bool proveriPar(Par p)
//{
//    try
//    {
//        konekcija.Open();
//        komanda.CommandText = "Select * from Par where " +
//            "cast(Datum as date)=cast('" + p.Datum.ToString("yyyy-MM-dd") + "'as date)" +
//            "and Domaci = " + p.Domacin.Id + " and Gost = " + p.Gost.Id + "";
//        SqlDataReader citac = komanda.ExecuteReader();
//        if (citac.Read())
//        {
//            citac.Close();
//            return true;
//        }

//        citac.Close();
//        return false;
//    }
//    catch (Exception)
//    {

//        throw;
//    }
//    finally
//    {
//        if (konekcija != null) konekcija.Close();

//    }
//}



//public bool obrisiPrijavu(string jmbg)
//{
//    try
//    {
//        konekcija.Open();
//        komanda.CommandText = "Select PrijavaID from Prijava where JMBG = '" + jmbg + "'";
//        int sifra = (int)komanda.ExecuteScalar();

//        komanda.CommandText = "Delete from Prijava where JMBG = '" + jmbg + "'";
//        komanda.ExecuteNonQuery();

//        komanda.CommandText = "Delete from StavkaPrijave where PrijavaID = " + sifra + "";
//        komanda.ExecuteNonQuery();

//        return true;
//    }
//    catch (Exception)
//    {

//        throw;
//    }
//    finally
//    {
//        konekcija.Close();
//    }
//}


//public Korisnik login(Korisnik korisnik)
//{
//    try
//    {
//        konekcija.Open();
//        komanda.CommandText = "Select * from Korisnik where KorisnickoIme = '" + korisnik.Username + "' and Lozinka = '" + korisnik.Lozinka + "'";
//        SqlDataReader reader = komanda.ExecuteReader();
//        if (reader.Read())
//        {
//            korisnik.KorisnikID = reader.GetInt32(0);
//            korisnik.Ime = reader.GetString(1);
//            korisnik.Prezime = reader.GetString(2);

//            reader.Close();
//            return korisnik;

//        }
//        reader.Close();
//        return null;
//    }
//    catch (Exception)
//    {

//        throw;
//    }
//    finally
//    {
//        konekcija.Close();
//    }
//}