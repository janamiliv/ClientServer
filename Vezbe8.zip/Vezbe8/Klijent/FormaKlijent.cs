﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class FormaKlijent : Form
    {
        Komunikacija k;
        public FormaKlijent()
        {
            InitializeComponent();
        }

        private void FormaKlijent_Load(object sender, EventArgs e)
        {
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "Povezan!";
            }
        }
    }
}































//private void btnObrisioBJ_Click(object sender, EventArgs e)
//{
//    try
//    {
//        Obj o = dataGridKlijent.CurrentRow.DataBoundItem as Obj;
//        listaObj.Remove(o);
//    }
//    catch (Exception)
//    {

//        MessageBox.Show("Niste odabrali objekat za brisanje!");
//    }
//}


//private void btnSacuvaj_Click(object sender, EventArgs e)
//{
//    // posto treba da se prosledi obicna a ne binding lista
//    // napravi se nova obicna lista, a u konstruktoru se 
//    // prosledi binding lista
//    if (k.sacuvajO(new List<O>(lista)))
//    {
//        MessageBox.Show("Sacuvani!");
//    }
//    else
//    {
//        MessageBox.Show("Nisu sacuvani!");
//    }
//}

//U klijent formi kad se kreira novi objekat u koji se ubacuju vrednosti:

//	Objekat o = new Objekat();
//o.Naziv = txtxNaziv.Text;
//o.Tip = cbTip.SelectedItem.ToString();
//o.Datum = DateTime.Parse(txtDat.Text);
//p.Datum = Convert.ToDateTime(DateTime.Now);
//p.Opstina = cbOpstina.SelectedItem as Opstina;
// p.Stavke = lista.ToList();


//void popuniGrid()
//{
//    DataGridViewComboBoxColumn domacin = new DataGridViewComboBoxColumn();
//    DataGridViewComboBoxColumn gost = new DataGridViewComboBoxColumn();

//    // naslov kolone
//    domacin.HeaderText = "Domacin";
//    // naziv za pristupanje koloni:
//    domacin.Name = "domacin";
//    // treba da bude isto kao property za klasu Domacin:
//    domacin.DataPropertyName = "Domacin";

//    gost.HeaderText = "Gost";
//    gost.Name = "gost";
//    gost.DataPropertyName = "Gost";

//b.ValueMember = "Objekat";
//b.DisplayMember = "Naziv";

//    dataGridKlijent.Columns.Add(domacin);
//    dataGridKlijent.Columns.Add(gost);

//    dataGridKlijent.AutoGenerateColumns = false;
//    listaParova = new BindingList<Par>();
//    dataGridKlijent.DataSource = listaParova;
//}




//private void btnLogin_Click(object sender, EventArgs e)
//{
//    try
//    {
//        Korisnik kor = new Korisnik();
//        kor.KorisnickoIme = txtUser.Text;
//        kor.Lozinka = txtLozinka.Text;

//        kor = k.login(kor);

//        if (kor == null)
//        {
//            MessageBox.Show("Neuspesno logovanje!");
//            return;

//        }
//        else
//        {
//            FormaKlijent forma = new FormaKlijent(kor);
//            this.Visible = false;
//            forma.ShowDialog();
//        }
//    }
//    catch (Exception ex)
//    {

//        MessageBox.Show(ex.Message);
//    }
//}

//Izmeni se Korisnicka forma tako da ovo bude na pocetku:

//	public partial class FormaKlijent : Form
//{
//    Korisnik prijavljeniKorisnik;
//    Komunikacija k;
//    public FormaKlijent(Domen.Korisnik kor)
//    { prijavljeniKorisnik=kor;
//.......



//Objekat o = dgvTestiranje.CurrentRow.DataBoundItem as Objekat;


//public Banka Objekat
//{
//    get
//    {
//        return this;
//    }
//}